/*
  ==============================================================================

    ValueTreeUpdater.h
    Created: 26 Feb 2016 11:17:48am
    Author:  Brett Porter

  ==============================================================================
*/

#ifndef VALUETREEUPDATER_H_INCLUDED
#define VALUETREEUPDATER_H_INCLUDED


#include "Controller.h"

/**
 * @class ValueTreeUpdater
 *
 * If client code makes changes to a ValueTree, we need to make sure that those
 * changes are propagated to the 'real' version of that ValueTree (that lives in the 
 * server process), as well as to any other clients that are listening to the server. 
 *
 * Our process here will be to make sure that before any client-side code that alters 
 * a ValueTree, we create one of these objects that is watching the tree. It'll capture the 
 * change update and send that down to the server.
 */
class ValueTreeUpdater
{
public:
   ValueTreeUpdater(ClientController* controller, uint32 code, ValueTree& tree);




private:
   ClientController* fController;
   

};


#endif  // VALUETREEUPDATER_H_INCLUDED
