

#ifndef IPCTEST_H_INCLUDED
#define IPCTEST_H_INCLUDED


//#define qUseNamedPipe

#define kPortNumber 0xec50
#define kPipeName "STREAMWARE"


#endif